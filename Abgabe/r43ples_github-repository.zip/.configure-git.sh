#!/bin/bash

git config --local user.email "r43ples-travis-ci@users.noreply.github.com"
git config --local user.name "r43ples travis-ci"
git config --local push.default simple 
