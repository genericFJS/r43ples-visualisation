# /bin/bash
jmeter -Jsample_variables=dataset,revision,changesize & 
